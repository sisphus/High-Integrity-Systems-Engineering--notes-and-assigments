with Ada.Text_IO; use Ada.Text_IO;

procedure Main with SPARK_Mode is
   Count : Integer;
   R : Integer;
begin
   Count := 0;
   R := 0;
   -- (1)
   while Count < 100 loop
      -- a loop invariant is a property that describes the behaviour of a loop
      -- in particular, a property that is true for each iteraction of the loop
      -- (i.e. describes an arbitrary iteration / execution of the loop body)
      --
      -- a loop invariant needs to satisfy 3 conditions:
      -- 1. it has to be true when we reach the loop (at positioin (1))
      -- 2. it has to remain true after each loo iteration
      -- 3. it has to be true after the loop finishes (at position (3))
      --
      -- Count   R
      -- ------------------
      -- 0       0
      -- 1       5
      -- 2       10
      -- 3       15
      -- ....
      -- 99      495
      -- pragma Loop_Invariant (R = 5 * Count);
      R := R + 5;
      Count := Count + 1;
   end loop;
   -- (3)
   pragma Assert (R = 500);
   Put_Line("The value of R is " & R'Image);

end Main;
